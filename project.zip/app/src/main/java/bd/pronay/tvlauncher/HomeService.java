package bd.pronay.tvlauncher;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;

import java.util.HashSet;
import java.util.Set;

public class HomeService extends AccessibilityService {

    private final Set<String> stockHomes = new HashSet<>();
    private long lastLaunch = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        refreshStockHomes();
    }

    private void refreshStockHomes() {
        stockHomes.clear();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        for (ResolveInfo ri : getPackageManager().queryIntentActivities(q, 0)) {
            stockHomes.add(ri.activityInfo.packageName);
        }
        stockHomes.remove(getPackageName());
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (stockHomes.isEmpty()) refreshStockHomes();
        if (stockHomes.contains(event.getPackageName().toString())) {
            goHome();
        }
    }

    private void goHome() {
        long now = SystemClock.uptimeMillis();
        if (now - lastLaunch < 800) return;
        lastLaunch = now;
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    @Override
    public void onInterrupt() { }
}
