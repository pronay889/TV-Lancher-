package bd.pronay.tvlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String PREFS = "launcher";
    private static final String KEY_HIDDEN = "hidden";
    private static final String KEY_FRONT = "front";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private LinearLayout row;
    private HorizontalScrollView scroller;
    private TextView clockView, dateView, nameView;
    private int focusIndex = 0;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateClock();
            handler.postDelayed(this, 10000);
        }
    };

    static class AppItem {
        String pkg;
        String label;
        ResolveInfo ri;
        Intent launch;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        populate();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        focusIndex = 0;
        focusChild(0);
    }

    @Override
    public void onBackPressed() {
        // A launcher never exits.
    }

    // ---------- UI ----------

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView label(int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setSingleLine(true);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1B2440, 0xFF0A0D18}));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setGravity(Gravity.END);
        clockView = label(44, true);
        dateView = label(18, false);
        dateView.setAlpha(0.7f);
        top.addView(clockView);
        top.addView(dateView);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.END);
        tp.setMargins(dp(32), dp(24), dp(48), 0);
        root.addView(top, tp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setClipChildren(false);
        nameView = label(30, true);
        nameView.setPadding(dp(48), 0, dp(48), dp(4));
        bottom.addView(nameView);

        scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setClipToPadding(false);
        scroller.setClipChildren(false);
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        row.setPadding(dp(48), dp(20), dp(28), dp(20));
        scroller.addView(row, new FrameLayout.LayoutParams(WRAP, WRAP));
        bottom.addView(scroller, new LinearLayout.LayoutParams(MATCH, WRAP));

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM);
        bp.bottomMargin = dp(48);
        root.addView(bottom, bp);
        setContentView(root);
    }

    private void updateClock() {
        Date now = new Date();
        clockView.setText(new SimpleDateFormat("h:mm a", Locale.getDefault()).format(now));
        dateView.setText(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now));
    }

    private GradientDrawable rounded(int fill) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(12));
        d.setColor(fill);
        return d;
    }

    private GradientDrawable border(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(12));
        d.setColor(Color.TRANSPARENT);
        d.setStroke(dp(3), color);
        return d;
    }

    private FrameLayout baseTile() {
        FrameLayout t = new FrameLayout(this);
        t.setBackground(rounded(0xFF2A3045));
        t.setClipToOutline(true);
        t.setForeground(border(Color.TRANSPARENT));
        t.setFocusable(true);
        t.setClickable(true);
        return t;
    }

    private LinearLayout.LayoutParams tileParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(200), dp(112));
        lp.rightMargin = dp(20);
        return lp;
    }

    private void attachFocus(final FrameLayout tile, final String name) {
        tile.setOnFocusChangeListener((v, has) -> {
            float s = has ? 1.12f : 1f;
            v.animate().scaleX(s).scaleY(s).setDuration(120).start();
            v.setTranslationZ(has ? dp(8) : 0);
            ((FrameLayout) v).setForeground(border(has ? Color.WHITE : Color.TRANSPARENT));
            if (has) {
                nameView.setText(name);
                focusIndex = row.indexOfChild(v);
            }
        });
    }

    private void focusChild(final int idx) {
        row.post(() -> {
            int n = row.getChildCount();
            if (n == 0) return;
            row.getChildAt(Math.max(0, Math.min(idx, n - 1))).requestFocus();
        });
    }

    // ---------- Apps ----------

    private void populate() {
        row.removeAllViews();
        for (AppItem item : loadApps()) {
            row.addView(makeTile(item), tileParams());
        }
        row.addView(makeSettingsTile(), tileParams());
        focusChild(focusIndex);
        updateClock();
    }

    private List<AppItem> loadApps() {
        PackageManager pm = getPackageManager();
        Set<String> hidden = prefs.getStringSet(KEY_HIDDEN, new HashSet<String>());
        Map<String, AppItem> map = new LinkedHashMap<>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || hidden.contains(pkg) || map.containsKey(pkg)) continue;
                AppItem a = new AppItem();
                a.pkg = pkg;
                a.ri = ri;
                a.label = String.valueOf(ri.loadLabel(pm));
                a.launch = new Intent(Intent.ACTION_MAIN)
                        .setClassName(pkg, ri.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                map.put(pkg, a);
            }
        }
        List<AppItem> out = new ArrayList<>();
        for (String p : frontList()) {
            AppItem a = map.remove(p);
            if (a != null) out.add(a);
        }
        List<AppItem> rest = new ArrayList<>(map.values());
        Collections.sort(rest, (x, y) -> x.label.compareToIgnoreCase(y.label));
        out.addAll(rest);
        return out;
    }

    private View makeTile(final AppItem item) {
        PackageManager pm = getPackageManager();
        FrameLayout tile = baseTile();
        Drawable banner = null;
        try {
            banner = item.ri.activityInfo.loadBanner(pm);
        } catch (Throwable ignored) { }
        ImageView img = new ImageView(this);
        if (banner != null) {
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setImageDrawable(banner);
            tile.addView(img, new FrameLayout.LayoutParams(MATCH, MATCH));
        } else {
            img.setImageDrawable(item.ri.loadIcon(pm));
            tile.addView(img, new FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER));
        }
        attachFocus(tile, item.label);
        tile.setOnClickListener(v -> safeStart(item.launch));
        tile.setOnLongClickListener(v -> {
            showAppMenu(item);
            return true;
        });
        return tile;
    }

    private View makeSettingsTile() {
        FrameLayout tile = baseTile();
        TextView t = label(22, true);
        t.setText("Settings");
        tile.addView(t, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));
        attachFocus(tile, "Settings");
        tile.setOnClickListener(v -> safeStart(new Intent(Settings.ACTION_SETTINGS)));
        tile.setOnLongClickListener(v -> {
            showLauncherMenu();
            return true;
        });
        return tile;
    }

    private void safeStart(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Cannot open", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- Menus ----------

    private void showAppMenu(final AppItem item) {
        String[] opts = {"Move to front", "Hide from home", "App info"};
        new AlertDialog.Builder(this).setTitle(item.label).setItems(opts, (d, which) -> {
            if (which == 0) {
                moveToFront(item.pkg);
                populate();
            } else if (which == 1) {
                hide(item.pkg);
                populate();
            } else {
                safeStart(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + item.pkg)));
            }
        }).show();
    }

    private void showLauncherMenu() {
        String[] opts = {"Show hidden apps", "Home key setup (Accessibility)"};
        new AlertDialog.Builder(this).setTitle("Clean Home").setItems(opts, (d, which) -> {
            if (which == 0) {
                prefs.edit().remove(KEY_HIDDEN).apply();
                populate();
            } else {
                safeStart(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }).show();
    }

    // ---------- Prefs ----------

    private List<String> frontList() {
        List<String> l = new ArrayList<>();
        for (String p : prefs.getString(KEY_FRONT, "").split(",")) {
            if (!p.isEmpty()) l.add(p);
        }
        return l;
    }

    private void moveToFront(String pkg) {
        List<String> l = frontList();
        l.remove(pkg);
        l.add(0, pkg);
        prefs.edit().putString(KEY_FRONT, TextUtils.join(",", l)).apply();
        focusIndex = 0;
    }

    private void hide(String pkg) {
        Set<String> h = new HashSet<>(prefs.getStringSet(KEY_HIDDEN, new HashSet<String>()));
        h.add(pkg);
        prefs.edit().putStringSet(KEY_HIDDEN, h).apply();
    }
}
